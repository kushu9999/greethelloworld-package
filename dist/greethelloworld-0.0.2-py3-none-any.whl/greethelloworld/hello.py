def sayHello(yourname="World"):
	return "Hello " + yourname
	

print(sayHello("kushal"))
