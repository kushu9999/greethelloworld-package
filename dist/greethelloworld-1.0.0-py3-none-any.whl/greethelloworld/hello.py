def sayHello(yourname="World"):
	return "Hello " + yourname